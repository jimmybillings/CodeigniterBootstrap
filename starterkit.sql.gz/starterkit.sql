-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 05, 2012 at 09:31 PM
-- Server version: 5.5.24
-- PHP Version: 5.3.10-1ubuntu3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `opsweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `password`, `question`, `answer`, `created`, `active`) VALUES
(1, 'james', 'jamesbonline@gmail.com', '4bbf2ddc38798e41cdc1d415c756faa92ba47ffd', '', '', '2012-11-04 11:11:37', 1),
(2, 'carolyne', 'carolyne@gmail.com', 'dcbc08b1640c45f045dd4fc3eb7477b13c6afad2', '', '', '2012-11-04 11:47:07', 1),
(3, 'james', 'jimmy@gmail.com', '4bbf2ddc38798e41cdc1d415c756faa92ba47ffd', '', '', '2012-11-04 13:36:15', 1),
(4, 'Madison', 'madison@gmail.com', '96773332455a5770cba61b43b62383e896c09c39', 'my dads name is', '474ba67bdb289c6263b36dfd8a7bed6c85b04943', '2012-11-04 14:36:52', 0),
(5, 'rachael', 'rachael@gmail.com', '4bbf2ddc38798e41cdc1d415c756faa92ba47ffd', 'some lover', '6544a1f18185a835a182f50973692b30d602bae4', '2012-11-04 21:08:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_check`
--

CREATE TABLE IF NOT EXISTS `user_check` (
  `user_id` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `id_check` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_check`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_check`
--

INSERT INTO `user_check` (`user_id`, `hash`, `id_check`) VALUES
(1, '116RawOYr12ZPk151410', 1),
(2, '17EpyXqQ4zOKnhYRGAN5', 2),
(3, 'TLEYgad2RS1417BscAI1', 3),
(4, 'o2gBqu1xvfpJw17N16VT', 4),
(5, '14rs17Jlyd184Gce13pq', 5);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
